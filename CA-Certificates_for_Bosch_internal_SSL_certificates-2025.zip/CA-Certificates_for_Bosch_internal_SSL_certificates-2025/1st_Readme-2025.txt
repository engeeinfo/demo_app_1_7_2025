This ZIP contains the current RSA CA certificates (RB RootCA RSA G01,RB IssuingCA RSA), the not yet issuing ECC CA certificates (RB RootCA ECC G01,RB IssuingCA ECC G20) and the soon expiring CA certificates (Bosch-CA-DE,Bosch-CA1-DE)



Current RSA CA Certificates

**************************************************************
sha256RSA Root-CA
--------------------------------------------------------------
RB RootCA RSA G01_bin.cer		Root CA as DER encoded binary
RB RootCA RSA G01_pem.cer		Root CA Base64 encoded

Certificate hashes:

SHA1: 8e468cb78e150cdb2473536693e14732b5075919
SHA256: befea4b1f8754f18c449a0d550ffe76daba609f410b65fed1bb4064aa6d9a306

If you already have it in your environment, please keep it there. If you haven't published it in your environment so far, please do so.
It is needed for a successful verification of the server certificates.

sha256RSA Intermediate CA 
--------------------------------------------------------------

RB IssuingCA RSA G21_bin.cer	Sub CA as DER encoded binary
RB IssuingCA RSA G21_pem.cer	Sub CA Base64 encoded

Certificate hashes:
 
SHA1: aaa9959f9fce64d4ba2b3c89de6f060eec5e9e6e
SHA256: 141d39a2cca1263a45c75468a0f8f4559c4ec319339b548487250fb394ead53a

You have to install either the DER encoded or Base64 encoded version of this certificate on your client and web server if you order a SHA-256RSA TLS certificate. 
It is needed for a successful verification of the server certificates.



Future ECC CA Certificates (Not yet in use)

**************************************************************
sha256ECDSA Root-CA
--------------------------------------------------------------
RB RootCA ECC G01-bin.cer		Root CA as DER encoded binary
RB RootCA ECC G01-pem.cer		Root CA Base64 encoded

Certificate hashes:

SHA1: e2193de57aab4c0c9e9bbcbe212e28360cf205cb
SHA256: 80630d1ffdac69622b039d490e910f5e7130f54606a6d73c9eed9522d06ef869

If you already have it in your environment, please keep it there. If you haven't published it in your environment so far, please do so.
It is needed for a successful verification of the server certificates. 

sha256ECDSA Intermediate CA 
--------------------------------------------------------------
RB IssuingCA ECC G20-bin.cer	Sub CA as DER encoded binary
RB IssuingCA ECC G20-pem.cer	Sub CA Base64 encoded

Certificate hashes:

SHA1: a218bfb845b1fa6e9ad09fd41c3bfced2c79629c
SHA256: 00cb4f7e80430746064d66945ae7902d3c642fc3bb22042813dedd7b863ce0d2

You have to install either the DER encoded or Base64 encoded version of this certificate on your client and web server if you order a SHA-256ECDSA TLS certificate. 
It is needed for a successful verification of the server certificates.


Old CA-Certificates expiring on 12.05.2025

**************************************************************
SHA-1 Root-CA
--------------------------------------------------------------
Bosch-CA-DE_bin.cer		Root CA as DER encoded binary
Bosch-CA-DE_pem.cer		Root CA Base64 encoded

Certificate hashes:

SHA1: 1409db46ebf376a8136c7f951e037349c28b64c8
SHA256: 84ffd8eb30fdd808af9175bdd5dade5efc74f81ea0300684085798e3d0349095

If you already have it in your environment, please keep it there. If you haven't published it in your environment so far, please do so.
It is needed for a successful verification of the server certificates. 

SHA-256 Intermediate CA 
--------------------------------------------------------------
Bosch-CA1-DE_150512_bin.cer	Sub CA as DER encoded binary
Bosch-CA1-DE_150512_pem.cer	Sub CA Base64 encoded

Certificate hashes:

SHA1: 9e008ec569cac6861786691c9118e57243c8f6db
SHA256: fc241995757b95946e7fb57d707d57c14751b3d91affcbf51360b7a1e671d6af

You have to install either the DER encoded or Base64 encoded version of this certificate on your client and web server if you order a sha256RSA TLS certificate. 
It is needed for a successful verification of the server certificates.
